package com.epsilon.usermicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsermicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
