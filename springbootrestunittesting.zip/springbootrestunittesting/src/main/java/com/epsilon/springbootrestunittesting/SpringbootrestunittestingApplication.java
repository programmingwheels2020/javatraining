package com.epsilon.springbootrestunittesting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootrestunittestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootrestunittestingApplication.class, args);
	}

}
