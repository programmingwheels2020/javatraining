package com.epsilon.mockitodemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockitodemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
