package com.epsilon.resttemplatedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResttemplatedemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResttemplatedemoApplication.class, args);
	}

}
